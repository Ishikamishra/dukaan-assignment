import "./App.css";
import DashboardHome from "./screens/DashboardHome";

function App() {
  return <div className="">
    <DashboardHome/>
  </div>;
}

export default App;
